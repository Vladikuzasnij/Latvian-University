# Programmas nosaukums: Lielāks skaitlis
# 3. uzdevums (MPR4)
# Uzdevuma formulējums: Izveidot programmu, kura pieprasa ievadīt divus skaitļus un paziņo, kurš no viņiem ir lielākais.
# Programmas autors: Vladislavs Babaņins
# Versija 1.0

print("\"Lielāks skaitļis\"\nVersija 1.0\n")


x=float(input("Ievadi x skaitli ===>"))
y=float(input("Ievadi y skaitli ===>"))

if (x>y):
    print("x > y\nx ir lielāks par y")
if (x<y):
    print("x < y\ny ir lielāks par x")
if (x==y):
    print("x==y\ny Nav lielāka skaitļa")